-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 08, 2021 at 03:19 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `itnsystems_ets`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_demo_result`
--

CREATE TABLE `tbl_demo_result` (
  `id` int(11) NOT NULL,
  `candidate_id` varchar(11) DEFAULT NULL,
  `exam_id` varchar(11) DEFAULT NULL,
  `result` enum('pass','fail') DEFAULT NULL,
  `candidate_mark` int(6) DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `modified_by` varchar(100) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `currentStatus` enum('y','n') NOT NULL DEFAULT 'n',
  `certificate` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_demo_result`
--

INSERT INTO `tbl_candidate_history` (`id`, `candidate_id`, `exam_id`, `result`, `candidate_mark`, `created_by`, `modified_by`, `created_date`, `modified_date`, `currentStatus`, `certificate`) VALUES
(1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'n', NULL),
(2, '123456', '236542', 'pass', 56, NULL, NULL, NULL, NULL, 'y', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_demo_result`
--
ALTER TABLE `tbl_demo_result`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_demo_result`
--
ALTER TABLE `tbl_demo_result`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
