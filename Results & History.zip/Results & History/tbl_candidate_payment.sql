-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 08, 2021 at 04:49 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `itnsystems_ets`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_candidate_payment`
--

CREATE TABLE `tbl_candidate_payment` (
  `id` int(11) NOT NULL,
  `candidate_name` varchar(25) DEFAULT NULL,
  `package_id` varchar(11) DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `total_tests` int(11) DEFAULT NULL,
  `used_tests` int(11) DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `modified_by` varchar(100) DEFAULT NULL,
  `created_date` datetime DEFAULT current_timestamp(),
  `modified_date` datetime DEFAULT current_timestamp(),
  `currentStatus` enum('y','n') NOT NULL DEFAULT 'n',
  `cost` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_candidate_payment`
--

INSERT INTO `tbl_candidate_payment` (`id`, `candidate_name`, `package_id`, `expiry_date`, `total_tests`, `used_tests`, `created_by`, `modified_by`, `created_date`, `modified_date`, `currentStatus`, `cost`) VALUES
(1, 'Sarthak D', '2', '2021-03-10', 600, 54, NULL, NULL, '2021-03-08 21:03:52', '2021-03-08 21:03:52', 'n', 3000),
(2, 'Sarthak Deshmukh', '3', '2021-03-12', 600, 86, NULL, NULL, '2021-03-08 21:06:44', '2021-03-08 21:06:44', 'y', 5000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_candidate_payment`
--
ALTER TABLE `tbl_candidate_payment`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_candidate_payment`
--
ALTER TABLE `tbl_candidate_payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
