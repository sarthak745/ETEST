<?php 
	
	error_reporting(0);
    include_once("classes/etsystem.php");
    $crud = new Etstysem();
	$query = "SELECT * FROM tbl_demo_result ORDER BY id DESC";
	$results = $crud->getData($query);

  

?>

<?php 
	include "includes/head-logo.php"; 
	include "includes/header.php"; 
	include "includes/sidebar.php"; 
?>

<section role="main" class="content-body">
					<header class="page-header">
						<h2>Demo Test History</h2>
					
						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="index.html">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>Table</span></li>
								<li><span>Test</span></li>
								<span>&nbsp&nbsp</span>
							</ol>
					
							<!-- <a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a> -->
						</div>
					</header>

					<!-- start: page -->
						<section class="panel">
							<header class="panel-heading">
								<div class="panel-actions">
									<!-- <a href="#" class="fa fa-caret-down"></a>
									<a href="#" class="fa fa-times"></a> -->
								</div>
   								<div class="row">
								   <h2 class="panel-title" style="display: inline-block;">Demo Test Result</h2>
                                   <span style="float: right;"><label><input type="search" class="form-control" placeholder="Search" aria-controls="datatable-editable"></label></span>
								<span>&nbsp&nbsp</span>
									<!-- <a type="button" style="float: right; margin-right: 80px;" class="btn btn-primary align-right"  href="add-candidate.php" >Add <i class="fa fa-plus"></i></a> -->
								</div>
							</header>
							<div class="panel-body">
								<!-- <div class="row">
									<div class="col-sm-6 col-md-9 d-inline">
										<div class="mb-md">
                                             <button id="addToTable" class="btn btn-primary">Add <i class="fa fa-plus"></i></button> 
                                            <
   										</div> -->
                                            
								<table class="table table-bordered table-striped mb-none" id="datatable-editable">
									<thead>
										<tr>
											<th>Sr. No </th>
											<th>Date</th>
											<th>Subject Name</th>
                                            <th>Test Name</th>
                                            <th>Score</th>
                                            <th>Status</th>
											
										</tr>
									</thead>
									<tbody>
										<?php $i =1; foreach ($results as $key => $row) { ?>
											<tr class="gradeX">
												<td><?php echo $i++; ?></td>
												<td><?php echo $row['created_date']; ?></td>
												<td><?php echo $row['subject']; ?></td>
												<td><?php echo $row['test_name']; ?></td>
												<td><?php echo $row['candidate_mark']; ?></td>
												<td><?php echo $row['currentStatus']; ?></td>                           
											</tr>
										<?php } ?>
									</tbody>
								</table>
							</div>
						</section>
					<!-- end: page -->
				</section>
			</div>
		</section>


<?php include "includes/footer.php"; ?>
